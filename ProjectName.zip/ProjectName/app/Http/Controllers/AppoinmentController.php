<?php

namespace App\Http\Controllers;
use App\Models\Appoinment;
use View;
use Illuminate\Http\Request;

class AppoinmentController extends Controller
{
    //

    public function appoinment(Request $request){

        $data = Appoinment::updateOrCreate(['id'=>$request->id],
            [
                "userId"=>1,
                "name"=>$request->name,
                "number"=>$request->number,
                "desc"=>$request->desc,
                "daytime"=>$request->daytime,

            ]);

            return View::make('dashboard', compact('data'));

    }
}

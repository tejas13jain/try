<?php

namespace App\Http\Controllers;
use App\Models\Users_details;
use App\Models\Appoinment;
use App\Models\description;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Session;

class DoctorController extends Controller
{
    public function dashboard(){
        return view('admin/dashboard');
    }

    public function patients (){
        $data = Appoinment::leftjoin('users_details','users_details.id','appoinments.userId')
                            ->select('appoinments.name','appoinments.id','appoinments.number','appoinments.desc','appoinments.daytime')->get();

        
        // print_r(json_encode($data)); die();
        return View::make('admin/dashboard', compact('data'));
    }

    public function approveAppoinment($id){

        Appoinment::where('id',$id)->update(['status'=>1]);

        return back()->with('success', 'Approve SuccessFully');   

        //return View::make('admin/dashboard');
    }

    public function rejectAppoinment($id){

        Appoinment::where('id',$id)->update(['status'=>0]);

        return back()->with('fail', 'REJECT SuccessFully');   
    }

    public function getAppoinment($id){

        $data = Appoinment::where('id',$id)->first();

        // print_r(json_encode($data)); die();

        return View::make('admin/description', compact('data')); 

        //return View::make('admin/dashboard');
    }

    public function drdescription(Request $request){

        $data = description::updateOrCreate(['id'=>$request->id],
            [
                "appoinmentId"=>$request->appoinmentId,
                "userId"=>$request->userId,
                "desc"=>$request->description,
                "schedule"=>$request->schedule
            ]);

            return back()->with('success', 'Approve SuccessFully');   
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Users_details;
use App\Models\Appoinment;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Session;
 
class UsersController extends Controller
{   
    public function companies(){
        return view('companies');
    }
    public function dashboard(){
        return view('dashboard');
    }
    public function Create(){
        return view('companies');
    }
    public function updatecompany(){
        return view('updatecompany');
    }
    public function signup(Request $request){

        $validator = Validator::make($request->all(), [ 
            'email' => 'required|unique:users_details',
            'password' => 'required',
        ]);

        $data = Users_details::updateOrCreate(
            [
                "name"=>$request->name,
                "email"=>$request->email,
                "password"=>$request->password,
                'user_type'=>'user'
            ]);
        
            if($data){
                return back()->with('success', 'Registration SuccessFully');   
  
            }else{
                return back()->with('fail', 'Something Wrong');   
            }
    }

    public function login(){
        return View::make('login');
    }
    public function loginUser(Request $request)
    {
        $validator = Validator::make($request->all(), [ 
            'email' => 'required',
            'password' => 'required',
        ]);

        $user = Users_details::where('email',$request->email)->first();

        if($user){
            if($request->password == $user->password){

                if($user->user_type == 'admin')
                {
                //  echo "hello"; die();
                    return redirect('admin/dashboard');
                }
                else if($user->user_type == 'user')
                {
                    //echo "hello"; die();
                    return redirect('dashboard');
                }
                // $request->session()->put('loginId',$user->id);
                // return redirect('dashboard');   

            }else{
                return back()->with('fail', 'Password Is Invalid');   

            }

        }else{
            return back()->with('fail', 'Something Wrong');   
        }
    }

    public function UserData(){
        $data = Appoinment::all();

        foreach($data as $m){
            if($m->status == 0){
                $m->status="Pending";
            }
            if($m->status == 1){
                $m->status="Approve";
            }
        }
        return View::make('dashboard', compact('data'));
    }
    public function UserDataById($id){
        $data = Users_details::where('id',$id)->first();
        return View::make('updatecompany', compact('data'));
    }
    public function DeleteUserDataById($id){
        $data = Users_details::where('id',$id)->delete();
        return back()->with('success', 'Delete SuccessFully');   
    }
    public function Updatesignup(Request $request){

        $data = Users_details::updateOrCreate(['id'=>$request->id],
            [
                "name"=>$request->name,
                "email"=>$request->email,
                "password"=>$request->password
            ]);

            return View::make('updatecompany', compact('data'));

    }

    public function appoinment(){
        return view('appoinment');
    }
}


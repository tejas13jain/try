<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Description</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</head>
<body>
    <div class="row">
    <div class="container col-md-8 mt-5">

            <h3>Signup</h3>
            <form method="POST" action="/drdescription">
            @csrf  
            @if(Session::has('success'))
            <div class="alert alert-primary" role="alert">
                {{Session::get('success')}}
           </div>
            @endif
            @if(Session::has('fail'))
            <div class="alert alert-danger" role="alert">
                {{Session::get('fail')}}
           </div>
            @endif
            <div class="container col-md-8">
            <div class="row mt-5">

            {{$data->name}} <br><br>
            {{$data->number}} <br><br>
            {{$data->daytime}}<br><br>
            {{$data->name}}<br><br>
            {{$data->desc}}<br><br>

          
            <div class="row mt-2">
                <label for="psw"><b>Description</b></label>
                <textarea class="form-control" name="description" id="description" rows="3"></textarea>
            </div>
            <div class="row mt-2">
                <label for="uname"><b>DayTime</b></label>
                <input type="text" placeholder="Day Time" name="schedule" id="schedule" required> 
            </div>
            <input type='hidden' name='appoinmentId' value='{{$data->id}}' />
            <input type='hidden' name='userId' value='{{$data->userId}}' />

            <div class="row mt-5">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            </form>
               
            </div>
            
           </form>
    

</div>
    </div>
</body>
</html>
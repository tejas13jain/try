<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Companies</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</head>
<body>
    <div class="row">
    <div class="container col-md-8 mt-5">
            <h3>Signup</h3>
            <form method="POST" action="/updatesignup" >
            @csrf  

            <div class="container">
                <div class="mt-5">
                <label for="uname"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="name" id="name" value="{{$data->name}}" required>
                </div>
                
                <div class="mt-2">
                <label for="uname"><b>Email</b></label>
                <input type="text" placeholder="Enter Email" name="email" id="email" value="{{$data->email}}" required> 
                </div>
                <div class="mt-2">
                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password" id="password" value="{{$data->password}}" required>
                </div>
                <input type='hidden' name='id' value='{{$data->id}}' />
                <div class="mt-2">
                <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </div>
           </form>
    

</div>
    </div>
</body>
</html>
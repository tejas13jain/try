<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\AppoinmentController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/', [UsersController::class, 'companies']);
Route::get('/login', [UsersController::class, 'login']);
Route::get('/dashboard', [UsersController::class, 'dashboard']);
Route::get('/dashboard', [UsersController::class, 'UserData']);

Route::get('/appoinment', [UsersController::class, 'appoinment']);



Route::get('/updatecompany', [UsersController::class, 'updatecompany']);
Route::get('/updatecompany/{id}', [UsersController::class, 'UserDataById']);
Route::get('/deleteUserDataById/{id}', [UsersController::class, 'DeleteUserDataById']);


Route::post('/signup', [UsersController::class, 'signup'])->name('signup');
Route::post('/loginUser', [UsersController::class, 'loginUser'])->name('loginUser');
Route::post('/updatesignup', [UsersController::class, 'Updatesignup'])->name('updatesignup');

Route::post('/appoinment', [AppoinmentController::class, 'appoinment'])->name('appoinment');



Route::get('/patients', [DoctorController::class, 'patients']);
Route::get('/admin/dashboard', [DoctorController::class, 'patients']);

Route::get('/approveAppoinment/{id}', [DoctorController::class, 'approveAppoinment']);
Route::get('/rejectAppoinment/{id}', [DoctorController::class, 'rejectAppoinment']);
Route::get('/admin/description/{id}', [DoctorController::class, 'getAppoinment']);



Route::post('/drdescription', [DoctorController::class, 'drdescription']);



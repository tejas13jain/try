<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Companies</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</head>
<body>
    <div class="row">
    <div class="container col-md-8 mt-5">

            <h3>Signup</h3>
            <form method="POST" action="/signup" >
            <?php echo csrf_field(); ?>  
            <?php if(Session::has('success')): ?>
            <div class="alert alert-primary" role="alert">
                <?php echo e(Session::get('success')); ?>

           </div>
            <?php endif; ?>
            <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('fail')); ?>

           </div>
            <?php endif; ?>
            <div class="container col-md-8">
            <div class="row mt-5">
                <label for="uname"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="name" id="name" required>
                </div>
                
                <div class="row mt-5">
                <label for="uname"><b>Email</b></label>
                <input type="text" placeholder="Enter Email" name="email" id="email" required> 
                </div>
                <div class="row mt-5">
                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password" id="password" required>
                </div>
                <div class="row mt-5">
                <button type="submit" class="btn btn-primary">Login</button>
                </div>
            </div>
            
           </form>
    

</div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\ProjectName\resources\views/companies.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</head>
<body>
    
    <div class="row">
    <div class="container col-md-8 mt-5">
        <a href="/" class="btn btn-primary">Add New User</a>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-primary" role="alert">
                <?php echo e(Session::get('success')); ?>

           </div>
            <?php endif; ?>
            <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('fail')); ?>

           </div>
            <?php endif; ?>
    <table class="table table-success table-striped mt-2">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Number</th>
            <th scope="col">Description</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <th scope="row"><?php echo e($item->id); ?></th>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->number); ?></td>
            <td><?php echo e($item->desc); ?></td>
            <td>
            <a href="admin/description/<?php echo e($item->id); ?>"  class="btn btn-danger">Description<i class="fa fa-pencil"></i></a >
            <form method="GET" action="/approveAppoinment/<?php echo e($item->id); ?>">
            <?php echo csrf_field(); ?>  
            <button type="submit" class="btn btn-primary mt-2">Approve<i class="fa fa-pencil"></i></button>
            </form>
            <form method="GET" action="/rejectAppoinment/<?php echo e($item->id); ?>">
            <?php echo csrf_field(); ?>  
            <button type="submit" class="btn btn-danger mt-3">Reject<i class="fa fa-pencil"></i></button >
            </form>
           </td>          
           </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\ProjectName\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>